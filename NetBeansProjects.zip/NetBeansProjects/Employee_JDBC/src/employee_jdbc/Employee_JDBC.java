/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employee_jdbc;

/**
 *
 * @author niteesh
 */
import java.sql.*;
public class Employee_JDBC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String user = "root";
        String pw = "root1234";
        String url = "jdbc:mysql://localhost:3306/jdbc?zeroDateTimeBehavior=CONVERT_TO_NULL";
        
        try
        {
            // Connect
            Connection c = DriverManager.getConnection(url, user, pw);
            
            // Check connection status
            if(c!=null)
            {
                System.out.println("Success");
                
//                String q = "create table if not exists test1(id int, name varchar(25))";
                
                Statement s = c.createStatement();
                
//                s.execute(q);
                
                // Query
                q = "insert into test1 values (101, 'abc')";
                
                // Execute the query
                s.executeUpdate(q);
            }
            else
                System.out.println("Fail");
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    
}
