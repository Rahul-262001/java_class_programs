/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jdbc1;

/**
 *
 * @author niteesh
 */
import java.sql.*;
public class JDBC1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String user = "root";
        String pw = "root1234";
        String url = "jdbc:mysql://localhost:3306/jdbc_db";
        
        try
        {
            // Load driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establish connection
            Connection c = DriverManager.getConnection(url, user, pw);
            
            if (c != null)
            {
                System.out.println("Successfully Connected");
                
                // Create a table using Statement
                Statement s1 = c.createStatement();
                String q = "create table if not exists Test1 (id INT, name varchar(25))";
                
                // Execute
                s1.executeUpdate(q);
                
                // Insert a record
//                q = "insert into Test1 values (101, 'Row 1')";
//                int r = s1.executeUpdate(q);
//                
//                if (r > 0)
//                    System.out.println("Record inserted");
//                else
//                    System.out.println("Insert failed");
                
                // Show the inserted record
                q = "select * from Test1";
                ResultSet rs = s1.executeQuery(q);
                
                while (rs.next())
                {
                    System.out.print("ID: "+rs.getString("id")+"\nName: "+rs.getString("name")+"\n");
                }
                rs.close();
                s1.close();
                c.close();
            }
            else
                System.out.println("Fail");
            
        }
        catch (Exception e)
        {
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
}
