/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jdbc2;

/**
 *
 * @author niteesh
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

/**
 *
 * @author niteesh
 */
import java.sql.*;
class JDBCInsert {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        
        String user = "root";
        String pw = "root1234";
        String url = "jdbc:mysql://localhost:3306/jdbc?zeroDateTimeBehavior=CONVERT_TO_NULL";
        
        try
        {
            Connection c = DriverManager.getConnection(url, user, pw);
            if(c!=null)
            {
                System.out.println("Successful connection");
                
                // Create a statement
                Statement s = c.createStatement();
                
                // Query
                String q = "insert into test1 values (101, 'abc')";
                
                // Execute the query
                s.executeUpdate(q);
            }
            else
                System.out.println("Connection failed");
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
        }
}
