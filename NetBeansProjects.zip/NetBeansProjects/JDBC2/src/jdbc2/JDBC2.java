/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jdbc2;

/**
 *
 * @author niteesh
 */
import java.sql.*;
public class JDBC2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String user = "root";
        String pw = "root1234";
        String url = "jdbc:mysql://localhost:3306/jdbc?zeroDateTimeBehavior=CONVERT_TO_NULL";
        
        try
        {
            // Connect
            Connection c = DriverManager.getConnection(url, user, pw);
            
            // Check connection status
            if(c!=null)
            {
                System.out.println("Success");
                
                String q = "create table if not exists test1(id int, name varchar(25))";
                
                Statement s = c.createStatement();
                
//                s.execute(q);
                
                // Query
//                q = "insert into test1 values (101, 'abc')";
                
                // Execute the query
//                s.executeUpdate(q);
                
                // Query
//                q = "insert into test1 values (102, 'def')";
                
                // Execute the query
//                s.executeUpdate(q);
                
                // Query
//                q = "insert into test1 values (103, 'ghi')";
                
                // Execute the query
//                s.executeUpdate(q);
                
//                q = "select * from test1";
                q = "desc test1";
                
                ResultSet rs = s.executeQuery(q);
                
//                rs.last();
                
//                do
                while(rs.next())
                {
                    System.out.println("Field: "+rs.getString("Field"));
                    System.out.println("Type: "+rs.getString("Type"));
                }
            }
            else
                System.out.println("Fail");
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    
}

