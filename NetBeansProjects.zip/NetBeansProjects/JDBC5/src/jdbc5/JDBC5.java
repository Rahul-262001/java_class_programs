/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jdbc5;

/**
 *
 * @author niteesh
 */
import java.sql.*;
public class JDBC5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String url = "jdbc:mysql://localhost:3306/jdbc?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String user = "root";
        String pw = "root1234";
        try
        {
            // Connect
            Connection c = DriverManager.getConnection(url, user, pw);
            if(c!=null)
            {
                System.out.println("Success");
                
                // Create a statement
                Statement s = c.createStatement();
                String q = "create table if not exists test3(id int, name varchar(20))";
                
                // Execute
                s.execute(q);
                
                // Insert a record
                q = "insert into test3 values (101, 'abc')";
//                int r = s.executeUpdate(q);
//                System.out.println(r+ " rows inserted");
                
                q = "insert into test3 values (102, 'def')";
//                System.out.println(s.executeUpdate(q)+" rows affected");
                // Prepared statement
                
                q = "insert into test3 values(?, ?)";
                PreparedStatement ps = c.prepareStatement(q);
                
//                ps.setInt(1, 103);
//                ps.setString(2, "ghi");
//                ps.executeUpdate();
                
                ps.setInt(1, 104);
                ps.setString(2, "jkl");
                ps.addBatch();
                
                ps.setInt(1, 105);
                ps.setString(2, "mno");
                ps.addBatch();
                
                ps.setInt(1, 106);
                ps.setString(2, "pqr");
                ps.addBatch();
                
//                System.out.println((ps.executeBatch().length)+" rows affected");
                
                // Select
                // executeQuery()
                q = "select * from test3";
                ResultSet rs = s.executeQuery(q);
                // Display
                rs.last();
                while(rs.next())
                {
                    System.out.println("ID: "+rs.getString("id"));
                    System.out.println("Name: "+rs.getString("name"));
                }
                
                q = "desc test3";
                rs = s.executeQuery(q);
                // Display
                while(rs.next())
                {
                    System.out.println("Column: "+rs.getString("field"));
                    System.out.println("Type: "+rs.getString("type"));
                }

                
            }
            else
                System.out.println("Fail");
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    
}
