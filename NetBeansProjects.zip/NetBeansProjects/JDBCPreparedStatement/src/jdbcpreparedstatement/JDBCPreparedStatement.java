/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jdbcpreparedstatement;

/**
 *
 * @author niteesh
 */
import java.sql.*;
public class JDBCPreparedStatement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // Username, password, and URL
        
        String user = "root", pw = "root1234";
        String url = "jdbc:mysql://localhost:3306/jdbc?zeroDateTimeBehavior=CONVERT_TO_NULL";
        
        try
        {
            // Establish connection
            
            Connection c = DriverManager.getConnection(url, user, pw);
            
            // Check connection
            if (c!=null)
            {
                System.out.println("Connection successful");
                
                // Create a table
                Statement s = c.createStatement();
//                s.execute("create table if not exists test2(id int, name varchar(20), phone varchar(10)");
                System.out.println("Table created");
                
                // Prepared Statement creation
                String q = "insert into test2 values (?, ?, ?)";
                PreparedStatement ps = c.prepareStatement(q);
                
                ps.setInt(1, 1001); // First param is column number, second is value
                ps.setString(2, "abc");
                ps.setString(3, "9988009988");
                
//                int r = ps.executeUpdate();
//                System.out.println(r+" rows affected");
                
                ps.setInt(1, 1002);
                ps.setString(2, "def");
                ps.setString(3, "8899887766");
                ps.addBatch();
                
                ps.setInt(1, 1003);
                ps.setString(2, "ghi");
                ps.setString(3, "8800887766");
                ps.addBatch();
                
//                ps.executeBatch();
//                System.out.println(r+ "rows affected");
                
                ResultSet rs = s.executeQuery("select * from test2");
                rs.last();
                do
                {
                    System.out.println("ID: "+rs.getInt("id"));
                    System.out.println("Name: "+rs.getString("name"));
                    System.out.println("Phone: "+rs.getString("phone"));
                }while(rs.previous());
                
                
            }
            else
                System.out.println("Connection failed");
          
            
        }
        
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
    
}
