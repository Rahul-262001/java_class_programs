/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jdbcprograms;

/**
 *
 * @author niteesh
 */
import java.sql.*;
public class JDBCPrograms {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String user = "root";
        String pw = "root1234";
        String url = "jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=CONVERT_TO_NULL";
        
     
        
        // Establish JDBC Connection
        try
        {
            // Load driver
//            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            Connection c = DriverManager.getConnection(url, user, pw);

            if(c!=null)
                System.out.println("Success");
            else
                System.out.println("Fail");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        
        // TODO code application logic here
    }
    
}
