/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jdbc_test2;

import java.sql.*;

/**
 *
 * @author niteesh
 */
public class JDBC_Test2 {

    public static void main(String[] args) {
//        System.out.println("Hello World!");
try {
//                        Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "root1234");

            // Create a statement
            Statement statement1 = connection.createStatement();

            // Define the SQL statement for table creation
            String sql = "CREATE TABLE IF NOT EXISTS example_table_2 ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "name VARCHAR(255),"
                    + "age INT"
                    + ")";

            // Execute the SQL statement
            statement1.executeUpdate(sql);

            System.out.println("Table created successfully");

            // Close the resources
            statement1.close();
            
            // Prepare an SQL statement for insertion
            String sql_insert = "INSERT INTO example_table_2 VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql_insert);

            // Set values for parameters in the SQL statement
            preparedStatement.setInt(1, 101);
            preparedStatement.setString(2, "ABCD");
            preparedStatement.setInt(3, 23);
            
            // Execute
            preparedStatement.executeUpdate();
            
            // Create a statement
            Statement statement = connection.createStatement();

            // Execute a query
            ResultSet resultSet = statement.executeQuery("SELECT * FROM example_table_2");

            // Process the result set
            while (resultSet.next()) {
                System.out.println(resultSet.getString("id"));
                System.out.println(resultSet.getString("name"));
                System.out.println(resultSet.getString("age"));
                
            }
//            System.out.println(resultSet);

            // Close the resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
//javac -cp .:mysql-connector-java-8.0.17.jar jdbc_test1.java
