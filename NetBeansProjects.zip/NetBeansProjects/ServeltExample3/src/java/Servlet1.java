import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try
        {
            // Set the response content type
            response.setContentType("text/html;charset=UTF-8");

//            // Get the input parameter (number) from the request
//            String numberParam = request.getParameter("n1");
//
//            // Convert the parameter to an integer
//            int number = Integer.parseInt(numberParam);
            String a = request.getParameter("un");
            String b = request.getParameter("pw");
            String r = "Invalid User";
            if(a.equals("root") && b.equals("root"))
                r = "Valid User";

            // Create HTML response
            PrintWriter out = response.getWriter();
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Number Display</title>");
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h2>Entered Number 1: " + a + "</h2><br>");
//            out.println("<h2>Entered Number 2: "+b+"</h2>");
//            out.println("<h2>Sum: "+(a+b)+"</h2>");
//            out.println("</body>");
//            out.println("</html>");
            
            out.println("<!DOCTYPE html>\n" +
"<html>\n" +
"<head>\n" +
"	<meta charset=\"utf-8\">\n" +
"	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"	<title>User Verification</title>\n" +
"</head>\n" +
"<body>\n" +	
"	<h2>Result: "+r+"</h2>\n" +
"</body>\n" +
"</html>");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
    }
}
